package com.example.lenovo.testdemoapp.roomdatabase

import android.arch.persistence.room.Database
import android.arch.persistence.room.Room
import android.arch.persistence.room.RoomDatabase
import android.content.Context
import com.example.lenovo.testdemoapp.model.RoomDAO
import com.example.lenovo.testdemoapp.model.RoomModel

@Database(entities = [RoomModel::class], version = 1, exportSchema = false)
abstract class RoomDb: RoomDatabase() {

    abstract fun makeDbOperations(): RoomDAO

    companion object {

        @Volatile
        private var INSTANCE: RoomDb? = null

        //Making Database as Singleton
        fun getDatabase(context: Context): RoomDb? {
            if (INSTANCE == null) {
                synchronized(RoomDb::class.java) {
                    if (INSTANCE == null) {
                        INSTANCE = Room.databaseBuilder(context.applicationContext, RoomDb::class.java, "room_database").build()
                    }
                }
            }
            return INSTANCE
        }
    }
}