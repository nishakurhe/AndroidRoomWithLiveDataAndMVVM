package com.example.lenovo.testdemoapp.views

import android.arch.lifecycle.ViewModelProviders
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.lenovo.testdemoapp.R
import com.example.lenovo.testdemoapp.model.RoomModel
import com.example.lenovo.testdemoapp.viewmodels.RoomViewModel
import kotlinx.android.synthetic.main.lay_add_room.*

class AddRoomFragment : Fragment() {

    private lateinit var roomViewModel: RoomViewModel

    // static object of AddRoomFragment
    companion object {
        fun newInstance(): AddRoomFragment {
            return AddRoomFragment()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        val addRoomView= inflater.inflate(R.layout.lay_add_room, container, false)

        return addRoomView
    }

    override fun onResume() {
        super.onResume()

        roomViewModel = ViewModelProviders.of(activity!!).get(RoomViewModel::class.java)

        btn_save.setOnClickListener {

            val rId = room_id
            val rName = room_name

            roomViewModel.insert(RoomModel(Integer.parseInt(rId.text.toString()), rName.text.toString()))

            fragmentManager?.popBackStack()
        }
    }
}