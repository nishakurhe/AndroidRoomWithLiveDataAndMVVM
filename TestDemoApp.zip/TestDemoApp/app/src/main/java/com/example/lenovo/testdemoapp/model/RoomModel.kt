package com.example.lenovo.testdemoapp.model

import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey

@Entity(tableName = "room_table")
class RoomModel (@PrimaryKey  var roomid:Int, var roomname:String)