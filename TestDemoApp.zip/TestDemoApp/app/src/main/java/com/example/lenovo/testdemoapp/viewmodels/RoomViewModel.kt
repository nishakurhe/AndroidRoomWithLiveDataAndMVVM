package com.example.lenovo.testdemoapp.viewmodels

import android.app.Application
import android.arch.lifecycle.AndroidViewModel
import android.arch.lifecycle.LiveData
import com.example.lenovo.testdemoapp.model.RoomModel
import com.example.lenovo.testdemoapp.roomdatabase.RoomDb
import com.example.lenovo.testdemoapp.roomdatabase.RoomRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class RoomViewModel(application: Application): AndroidViewModel(application) {

     var roomRepository: RoomRepository? = null

    val cc = Job() + Dispatchers.Main

    val coroutineScope:CoroutineScope = CoroutineScope(cc)

    var roomList: LiveData<List<RoomModel>>? = null

    init {
        val db = RoomDb.getDatabase(application.applicationContext)
        if(db!=null) {
            val roomdao = db.makeDbOperations()
            roomRepository = RoomRepository(roomdao)
            roomList = roomRepository?.allRooms
        }
    }

    fun insert(roomModel: RoomModel) = coroutineScope.launch(Dispatchers.IO) {
        roomRepository?.insertRoom(roomModel)
    }

}