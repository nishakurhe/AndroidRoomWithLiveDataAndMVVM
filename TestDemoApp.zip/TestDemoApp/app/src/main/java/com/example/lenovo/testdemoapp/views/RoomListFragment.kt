package com.example.lenovo.testdemoapp.views

import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.databinding.DataBindingUtil
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.lenovo.testdemoapp.BR
import com.example.lenovo.testdemoapp.R
import com.example.lenovo.testdemoapp.databinding.LayRoomAdapterBinding
import com.example.lenovo.testdemoapp.model.RoomModel
import com.example.lenovo.testdemoapp.viewmodels.RoomViewModel
import kotlinx.android.synthetic.main.lay_room_list.*
import java.util.ArrayList

class RoomListFragment: Fragment() {

    private lateinit var roomAdapter: RoomAdapter

    private lateinit var roomViewModel: RoomViewModel

    // static object of RoomListFragment
    companion object {
        fun newInstance(): RoomListFragment {
            return RoomListFragment()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        val roomListView= inflater.inflate(R.layout.lay_room_list, container, false)
        return roomListView
    }

    override fun onResume() {
        super.onResume()

        add_btn.setOnClickListener {
            fragmentManager!!.beginTransaction().add(R.id.frame_layout, AddRoomFragment.newInstance()).addToBackStack("backStack").commit()
        }

         roomViewModel = ViewModelProviders.of(activity!!).get(RoomViewModel::class.java)

        roomAdapter = RoomAdapter(ArrayList<RoomModel>())
        room_recycler.adapter = roomAdapter
        room_recycler.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL,false);

        roomViewModel.roomList?.observe(this, Observer {
            it?.let {
                roomAdapter.roomList = ArrayList(it)
                roomAdapter.notifyDataSetChanged();
            }
        })
    }

       private class RoomAdapter(var roomList: List<RoomModel>): RecyclerView.Adapter<RoomAdapter.RoomViewHolder>() {

           override fun onCreateViewHolder(p0: ViewGroup, p1: Int): RoomViewHolder {

               val roomView:View = LayoutInflater.from(p0.context).inflate(R.layout.lay_room_adapter, p0, false)
               val itemBinding = DataBindingUtil.bind<LayRoomAdapterBinding>(roomView)
               return RoomViewHolder(roomView, itemBinding!!)
           }

           override fun getItemCount(): Int {
               return roomList.size
           }

           override fun onBindViewHolder(holder: RoomViewHolder, position: Int) {

               holder.binding.setVariable(BR.modelroom, roomList.get(position))
               holder.binding.executePendingBindings()
           }

           class RoomViewHolder(itemView: View, var binding: LayRoomAdapterBinding): RecyclerView.ViewHolder(itemView) {
           }
       }
}