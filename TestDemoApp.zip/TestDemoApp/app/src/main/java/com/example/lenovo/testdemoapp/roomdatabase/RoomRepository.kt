package com.example.lenovo.testdemoapp.roomdatabase

import android.arch.lifecycle.LiveData
import android.support.annotation.WorkerThread
import com.example.lenovo.testdemoapp.model.RoomDAO
import com.example.lenovo.testdemoapp.model.RoomModel

class RoomRepository constructor(private val rooomDao : RoomDAO){

    var allRooms:LiveData<List<RoomModel>> = rooomDao.getAllRoomList()

    @WorkerThread
    fun insertRoom(roommodel : RoomModel) {
        rooomDao.insert(roommodel)
    }
}