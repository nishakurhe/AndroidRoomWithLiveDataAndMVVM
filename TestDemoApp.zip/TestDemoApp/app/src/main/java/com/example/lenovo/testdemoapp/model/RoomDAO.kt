package com.example.lenovo.testdemoapp.model

import android.arch.lifecycle.LiveData
import android.arch.persistence.room.Dao
import android.arch.persistence.room.Insert
import android.arch.persistence.room.Query

@Dao
interface RoomDAO{
    @Query("select * from room_table")
    fun getAllRoomList(): LiveData<List<RoomModel>>

    @Insert
    fun insert(todo: RoomModel)
}